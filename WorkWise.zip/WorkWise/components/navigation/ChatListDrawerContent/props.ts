import { DrawerContentComponentProps } from '@react-navigation/drawer'

export type Props = {} & DrawerContentComponentProps
