export { ViewProps as Props } from 'react-native'
