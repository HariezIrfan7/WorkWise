import { ViewProps } from 'react-native'

export type Props = {} & ViewProps
