import { MMKV } from 'react-native-mmkv'

export const kvStorage = new MMKV()
